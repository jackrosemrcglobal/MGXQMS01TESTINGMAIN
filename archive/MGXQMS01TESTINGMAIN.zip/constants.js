export const LOCAL_STORAGE_THEME_KEY = 'qms-theme';
export const LOCAL_STORAGE_MODULES_KEY = 'qms-enabled-modules';

